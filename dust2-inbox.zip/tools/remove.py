"""Manual removals, batched.

Boxes named here are deleted from the plan. This is the list for things
found by eye in the viewer that no automated rule caught.

Run LAST in the pipeline, after gapfill.py.
"""
import json

REMOVE = [
    # Door leaves missed by doors.py: it shortlisted axis-aligned
    # door-shaped solids, and these are `compound` brushes (angled panels
    # reduced to bounding boxes), so they were never candidates. The wall
    # doubling then stretched them to 13.7 m.
    'compound_201',
    'compound_203',
    # Six more, same signature: paired leaves, 1-4 m wide, yawed, stretched
    # tall by the wall doubling. Long, mid and the B-side opening.
    'compound_196',
    'compound_197',
    'compound_118',
    'compound_117',
    'compound_374',
    'compound_375',
    # Gantry braces, 2026-08-16. Four facing pairs of 45 deg slabs with a
    # 53 x 53 cross section, flanking a pole that carries a platform
    # (ramp_818, ramp_837, ramp_840, ramp_843). Three of the four pairs sit
    # 72 to 125 u above the main floor, so with hero at 120 u they were
    # head-height clutter under an overhead structure. No other box in the
    # plan matches this signature.
    'ramp-slab_817',
    'ramp-slab_819',
    'ramp-slab_836',
    'ramp-slab_838',
    'ramp-slab_839',
    'ramp-slab_841',
    'ramp-slab_842',
    'ramp-slab_844',
    # Two flat plates at z 613 to 640, 26.7 thick, yawed 63.4 and 32.0.
    # Unlike the braces these were standable surface, so removing them
    # takes reachable cells out of the plan. Removed intentionally.
    'yaw_472',
    'yaw_474',
]

p = json.load(open('dust2_half.json'))
before = len(p['boxes'])
gone = [b['name'] for b in p['boxes'] if b['name'] in REMOVE]
p['boxes'] = [b for b in p['boxes'] if b['name'] not in REMOVE]
json.dump(p, open('dust2_half.json','w'), indent=1)

missing = [n for n in REMOVE if n not in gone]
print(f'removed {len(gone)} of {len(REMOVE)} listed: {gone}')
if missing: print(f'NOT FOUND (already gone or renamed): {missing}')
print(f'plan {before} -> {len(p["boxes"])} boxes')
